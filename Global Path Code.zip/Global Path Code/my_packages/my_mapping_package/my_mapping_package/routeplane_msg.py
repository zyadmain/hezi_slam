import math
import rclpy
from rclpy.node import Node
#from perception_msgs.msg import PerceptionObjects, PerceptionLocalization, TrafficLightDetection
#from control_msgs.msg import ControlCmd   
#from device_msgs.msg import taskpublish  
#from device_msgs.msg import participantTrajectories
#import time
import numpy as np
#from common_msgs.msg import Header
#from perception_msgs.msg import RoadMarkers
from std_msgs.msg import String
import os
#import sys
#sys.path.append('/home/field/dev_ws/src/pos_judege/utils/opendrive2discretenet')
from utils.opendrive2discretenet.__init__ import init_plane,operation_cloudpoint
from pos_interfaces.msg import Pos

class RosMsg(Node):
    #创建一个节点来订阅并发布本车与目标点是否可行的判断结果
    def __init__(self,name):
        super().__init__(name)
        self.get_logger().info("ok")
        road_info = init_plane()  #节点初始化时就将地图数据进行加载好
        self.subscription = self.create_subscription(
            String,  # 订阅的消息类型   先是本车位置
            'chatter',  # 订阅的话题名称
            lambda msg:  self.listener_callback(self,msg,road_info),  # 回调函数
            10  # 队列大小
        )
        self.pub_novel = self.create_publisher(Pos,"pos_publish", 10)        
  

    def calculate_and_publish(self,road_info,pos,self_pos):
        # 这里进行数据计算
        #result = operation(pos,self_pos,road_info)  #result 是一个二维数组
        result = operation_cloudpoint(pos,self_pos,road_info)
        # 创建消息并发布
        msg_publish = Pos()
        msg_publish.data = result
        self.publisher_.publish(msg_publish)
            

    def listener_callback(self,msg,road_info): #msg为订阅的消息内容 即车本身的坐标和目标点坐标
        pos_arr = msg.split(",")
         #本车自己的位置
        self_x = float(pos_arr[0])
        self_y = float(pos_arr[1])
        #目标区域的位置
        pos_x = float(pos_arr[2])
        pos_y = float(pos_arr[3])
       
        self_pos = [self_x,self_y]
        pos = [pos_x,pos_y]
        self.calculate_and_publish(self,road_info,pos,self_pos)
        self.get_logger().info("publish is OK")


def main(args=None):
    rclpy.init(args=args) # 初始化rclpy
    node = RosMsg("posMsg")  # 新建一个节点
    rclpy.spin(node) # 保持节点运行，检测是否收到退出指令（Ctrl+C）
    rclpy.shutdown() # 关闭rclpy