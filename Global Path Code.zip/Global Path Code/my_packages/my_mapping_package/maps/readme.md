Maps are in the /maps directory, separated by format. The maps used in this project are in OpenDRIVE format (xodr files). Inside the /xodr directory, some of the maps are classfied by their CARLA version. 

Last stable version of the CAMPUS UAH map is:
* CampusUAH_v1_7.xodr