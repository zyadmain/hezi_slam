Debug files to check the functinality of different parts of the code:

(Each debug file is explained itself in the code)

* debug_get_closer_right_waypoint.py
* debug_get_waypoint.py
* test_map_parser.py