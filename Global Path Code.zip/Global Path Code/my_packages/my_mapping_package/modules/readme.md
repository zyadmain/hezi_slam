Modules that are used in the Mapping Layer:

(Each module is explained itself in the code)
* calculus_module.py
* junctions_module.py
* lanes_module.py
* markers_module.py
* monitor_classes.py
* monitor_module.py
* regElem_module.py
* route_module.py