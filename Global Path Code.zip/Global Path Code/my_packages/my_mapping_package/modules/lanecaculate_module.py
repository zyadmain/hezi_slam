


import numpy as np
from shapely.geometry import Point, Polygon



from lxml import etree
import os
import sys
sys.path.append('/home/field/dev_ws/src/my_packages')
from utils.opendrive2discretenet.opendriveparser.parser import parse_opendrive as parse_opendrive_xml
from utils.opendrive2discretenet.network import Network
#import matplotlib.path as mpath
#import matplotlib.pyplot as plt
import numpy as np
from shapely.geometry import Point, Polygon

def parse_opendrive(path_opendrive: str) -> None:
    """
    解析opendrive路网的信息，存储到self.replay_info.road_info。
    """
    with open(path_opendrive, 'r', encoding='utf-8') as fh:
        root = etree.parse(fh).getroot()
    
    # 返回OpenDrive类的实例对象（经过parser.py解析）
    openDriveXml = parse_opendrive_xml(root)

    # 将OpenDrive类对象进一步解析为参数化的Network类对象，以备后续转化为DiscreteNetwork路网并可视化
    loadedRoadNetwork = Network()
    loadedRoadNetwork.load_opendrive(openDriveXml)

    """将解析完成的Network类对象转换为DiscreteNetwork路网，其中使用的只有路网中各车道两侧边界的散点坐标
        车道边界点通过线性插值的方式得到，坐标点储存在<DiscreteNetwork.discretelanes.left_vertices/right_vertices> -> List"""
    open_drive_info = loadedRoadNetwork.export_discrete_network(
        filter_types=["driving","biking", "onRamp", "offRamp", "exit", "entry", "sidewalk"])  # -> <class> DiscreteNetwork
    return open_drive_info
    

def is_point_inside(rect, egoPos, pos) -> bool:
    """
    判断一个点是否在一个矩形内部 (bottom-left and top-right).
    Returns:
    - bool: True 则到达了这个面域内部, False 则没有.
    """
    #将两个数组进行堆叠
    #merged_arr = np.vstack((rect,egoPos))    
    #计算边界点数组的大小
    merged_arr_nplen_rect = len(rect)
    merged_arr_nplen_egoPos = len(egoPos)
    polygon_arr = []
    for i in range(merged_arr_nplen_rect):
        polygon_arr.append((rect[i][0],rect[i][1]))
    
    for j in range(merged_arr_nplen_egoPos-1,-1,-1):   #这里一定要注意坐标的顺序，一定要保证顺时针或者逆时针
        polygon_arr.append((egoPos[j][0],egoPos[j][1]))

    point = Point(pos[0],pos[1])
    
    polygon = Polygon(polygon_arr)
    #将坐标进行比较
    return point.within(polygon)  # 输出: True

def init_plane():
    path_opendrive = '/home/field/hezimap.xodr'
    road_info = parse_opendrive(path_opendrive)
    return road_info

def operation_cloudpoint(self_pos,road_info):
     #需要获取road名称 lane_id 获取本车的车道号
    plane_count = len(road_info.discretelanes)
    for i  in range(plane_count):   #这一块后面还要修改
        if(is_point_inside(road_info.discretelanes[i].left_vertices,road_info.discretelanes[i].right_vertices,self_pos)==True):
            total_arr = np.vstack((np.array(road_info.discretelanes[i].left_vertices),np.array(road_info.discretelanes[i].right_vertices)))
            print(road_info.discretelanes[i]._lane_id)
            break
    return total_arr

def operation(pos,self_pos,road_info): #self_pos表示本车位置，pos表示目标车位置
    #需要获取road名称 lane_id 获取本车的车道号
    plane_count = len(road_info.discretelanes)
    predecessor = []
    successor = []
    lane_id_self_pos = ''
    lane_id_pos = ''
    for i  in range(plane_count):   #这一块后面还要修改
        if(is_point_inside(road_info.discretelanes[i].left_vertices,road_info.discretelanes[i].right_vertices,self_pos)==True):
            print(road_info.discretelanes[i]._lane_id)
            lane_id_self_pos = road_info.discretelanes[i]._lane_id
            predecessor = road_info.discretelanes[i]._predecessor
            successor= road_info.discretelanes[i]._successor
        #把目标的位置车道定出来
        if(is_point_inside(road_info.discretelanes[i].left_vertices,road_info.discretelanes[i].right_vertices,pos)==True):
            lane_id_pos = road_info.discretelanes[i]._lane_id
   
    
    #print(road_info.discretelanes[5]._successor) ==>['134.0.-1.-1', '138.0.-1.-1']   而且也有空集
    predecessor_count = len(predecessor)
    successor_count = len(successor)
    predecessor_plane_type = []
    successor_plane_type = [] 
    if(successor_count !=0):
        for i in range(plane_count):
            for j in range(successor_count):
                if(successor[j] == road_info.discretelanes[i]._lane_id):
                    successor_plane_type.append(road_info.discretelanes[i]._parametric_lane_group.parametric_lanes[0].type_)
            
    if(predecessor_count !=0):
        for i in range(plane_count):
            for j in range(predecessor_count ):
                if(predecessor[j] == road_info.discretelanes[i]._lane_id):
                    predecessor_plane_type.append(road_info.discretelanes[i]._parametric_lane_group.parametric_lanes[0].type_)

    #判断相邻路段能不能进行行驶
    border_plane = []
    border_plane_type = []

    lane_id_self_pos_arr = lane_id_self_pos.split('.')
    for i  in range(plane_count):
        lane_id_arr = road_info.discretelanes[i]._lane_id.split('.')
        if(lane_id_arr[0] == lane_id_self_pos_arr[0]):
            border_plane.append(road_info.discretelanes[i]._lane_id)
            border_plane_type.append(road_info.discretelanes[i]._parametric_lane_group.parametric_lanes[0].type_)

     
    #for j in range()
    if(lane_id_pos in border_plane):
       if(border_plane_type[border_plane.index(lane_id_pos)] == 'driving'):
          return True
       else:
          return False
    elif(predecessor_count !=0 and (lane_id_pos in predecessor) == True):
       if(predecessor_plane_type[predecessor.index(lane_id_pos)] == 'driving'):
          return True
       else:
          return False
    elif(successor_count !=0 and (lane_id_pos in successor) == True):
       if(successor_plane_type[successor.index(lane_id_pos)] == 'driving'):
           return True
       else:
           return False
    else:
       return False    
