Different modules that are used in the Planning layer. In this case the only util module is:

* markers_module.py: Functions to obtain ROS markers for different messages as lanes, ways, ... and visualize them in RVIZ
