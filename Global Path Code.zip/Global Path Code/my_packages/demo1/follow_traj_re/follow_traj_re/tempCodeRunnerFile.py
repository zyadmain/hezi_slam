        global_yaw = local_yaw - (math.pi/2 - state.yaw)
