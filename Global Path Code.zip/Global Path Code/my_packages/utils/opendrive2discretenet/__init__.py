from lxml import etree
import os
import sys
sys.path.append('/home/field/dev_ws/src/pos_judege')
from utils.opendrive2discretenet.opendriveparser.parser import parse_opendrive as parse_opendrive_xml
from utils.opendrive2discretenet.network import Network
#import matplotlib.path as mpath
#import matplotlib.pyplot as plt
import numpy as np
from shapely.geometry import Point, Polygon

def parse_opendrive(path_opendrive: str) -> None:
    """
    解析opendrive路网的信息，存储到self.replay_info.road_info。
    """
    with open(path_opendrive, 'r', encoding='utf-8') as fh:
        root = etree.parse(fh).getroot()
    
    # 返回OpenDrive类的实例对象（经过parser.py解析）
    openDriveXml = parse_opendrive_xml(root)

    # 将OpenDrive类对象进一步解析为参数化的Network类对象，以备后续转化为DiscreteNetwork路网并可视化
    loadedRoadNetwork = Network()
    loadedRoadNetwork.load_opendrive(openDriveXml)

    """将解析完成的Network类对象转换为DiscreteNetwork路网，其中使用的只有路网中各车道两侧边界的散点坐标
        车道边界点通过线性插值的方式得到，坐标点储存在<DiscreteNetwork.discretelanes.left_vertices/right_vertices> -> List"""
    open_drive_info = loadedRoadNetwork.export_discrete_network(
        filter_types=["driving","biking", "onRamp", "offRamp", "exit", "entry", "sidewalk"])  # -> <class> DiscreteNetwork
    return open_drive_info
    



def is_point_inside(rect, egoPos, pos) -> bool:
    """
    判断一个点是否在一个矩形内部 (bottom-left and top-right).
    Returns:
    - bool: True 则到达了这个面域内部, False 则没有.
    """
    #将两个数组进行堆叠
    #merged_arr = np.vstack((rect,egoPos))    
    #计算边界点数组的大小
    merged_arr_nplen_rect = len(rect)
    merged_arr_nplen_egoPos = len(egoPos)
    polygon_arr = []
    for i in range(merged_arr_nplen_rect):
        polygon_arr.append((rect[i][0],rect[i][1]))
    
    for j in range(merged_arr_nplen_egoPos-1,-1,-1):   #这里一定要注意坐标的顺序，一定要保证顺时针或者逆时针
        polygon_arr.append((egoPos[j][0],egoPos[j][1]))

    point = Point(pos[0],pos[1])
    
    polygon = Polygon(polygon_arr)
    #将坐标进行比较
    return point.within(polygon)  # 输出: True

def init_plane():
    path_opendrive = '/home/field/hezimap.xodr'
    road_info = parse_opendrive(path_opendrive)
    return road_info


def operation_cloudpoint(pos,self_pos,road_info):
     #需要获取road名称 lane_id 获取本车的车道号
    plane_count = len(road_info.discretelanes)
    for i  in range(plane_count):   #这一块后面还要修改
        if(is_point_inside(road_info.discretelanes[i].left_vertices,road_info.discretelanes[i].right_vertices,self_pos)==True):
            total_arr = np.vstack((np.array(road_info.discretelanes[i].left_vertices),np.array(road_info.discretelanes[i].right_vertices)))
    return total_arr

def operation(pos,self_pos,road_info): #self_pos表示本车位置，pos表示目标车位置
    #需要获取road名称 lane_id 获取本车的车道号
    plane_count = len(road_info.discretelanes)
    predecessor = []
    successor = []
    lane_id_self_pos = ''
    lane_id_pos = ''
    for i  in range(plane_count):   #这一块后面还要修改
        if(is_point_inside(road_info.discretelanes[i].left_vertices,road_info.discretelanes[i].right_vertices,self_pos)==True):
            print(road_info.discretelanes[i]._lane_id)
            lane_id_self_pos = road_info.discretelanes[i]._lane_id
            predecessor = road_info.discretelanes[i]._predecessor
            successor= road_info.discretelanes[i]._successor
        #把目标的位置车道定出来
        if(is_point_inside(road_info.discretelanes[i].left_vertices,road_info.discretelanes[i].right_vertices,pos)==True):
            lane_id_pos = road_info.discretelanes[i]._lane_id
   
    
    #print(road_info.discretelanes[5]._successor) ==>['134.0.-1.-1', '138.0.-1.-1']   而且也有空集
    predecessor_count = len(predecessor)
    successor_count = len(successor)
    predecessor_plane_type = []
    successor_plane_type = [] 
    if(successor_count !=0):
        for i in range(plane_count):
            for j in range(successor_count):
                if(successor[j] == road_info.discretelanes[i]._lane_id):
                    successor_plane_type.append(road_info.discretelanes[i]._parametric_lane_group.parametric_lanes[0].type_)
            
    if(predecessor_count !=0):
        for i in range(plane_count):
            for j in range(predecessor_count ):
                if(predecessor[j] == road_info.discretelanes[i]._lane_id):
                    predecessor_plane_type.append(road_info.discretelanes[i]._parametric_lane_group.parametric_lanes[0].type_)

    #判断相邻路段能不能进行行驶
    border_plane = []
    border_plane_type = []
    print(lane_id_self_pos+"^^^")
    lane_id_self_pos_arr = lane_id_self_pos.split('.')
    for i  in range(plane_count):
        lane_id_arr = road_info.discretelanes[i]._lane_id.split('.')
        if(lane_id_arr[0] == lane_id_self_pos_arr[0]):
            border_plane.append(road_info.discretelanes[i]._lane_id)
            border_plane_type.append(road_info.discretelanes[i]._parametric_lane_group.parametric_lanes[0].type_)

     
    print(border_plane_type)
    print(border_plane)
    #for j in range()
    if(lane_id_pos in border_plane):
       if(border_plane_type[border_plane.index(lane_id_pos)] == 'driving'):
          return True
       else:
          return False
    elif(predecessor_count !=0 and (lane_id_pos in predecessor) == True):
       if(predecessor_plane_type[predecessor.index(lane_id_pos)] == 'driving'):
          return True
       else:
          return False
    elif(successor_count !=0 and (lane_id_pos in successor) == True):
       if(successor_plane_type[successor.index(lane_id_pos)] == 'driving'):
           return True
       else:
           return False
    else:
       return False    

def per_laneget(self_pos,road_info):  #初始
    len_object = len(road_info.discretelanes)

    return

def main():
    #path_opendrive = r"H:\onsite结构化测试赛道\最新版本\onsite_structured_test\scenario\replay\intersection_12_61_0\intersection_12_61_0.xodr"
    path_opendrive = '/home/field/hezimap.xodr'
    road_info = parse_opendrive(path_opendrive)
    #print(type(road_info.discretelanes[11]._lane_id))
    #print(road_info.discretelanes)
    #print("ok")
    '''
    x1 = road_info.discretelanes[11].left_vertices[:,0]
    y1 = road_info.discretelanes[11].left_vertices[:,1]
    x2 = road_info.discretelanes[11].right_vertices[:,0]
    y2 = road_info.discretelanes[11].right_vertices[:,1]
    laneid = road_info.discretelanes[11].lane_id
    predecessorid = road_info.discretelanes[11].predecessor
    '''
    #print(road_info.discretelanes[11].right_vertices)
    
    #merged_arr = np.vstack((road_info.discretelanes[11].left_vertices,road_info.discretelanes[11].right_vertices))
     
    #print(len(road_info.discretelanes))
    
    
    #print(merged_arr_x)  
    #print(merged_arr_y)
    pos = [663.00,-120.26]
    self_pos = [692.88,-129.66]
    plane_count = len(road_info.discretelanes)
    print(road_info.discretelanes[11].parametric_lanes)
    '''
    for i  in range(plane_count):
        if(road_info.discretelanes[i]._lane_id == '84.0.-2.-1'):  ==>237
            print(i)
            print(road_info.discretelanes[i].left_vertices)
            print('*****')
            print(road_info.discretelanes[i].right_vertices)
    #         print("OK")
    #plane_count = len(road_info.discretelanes)
    #print(operation(pos,self_pos,road_info))
    '''
    #print(is_point_inside(road_info.discretelanes[237].left_vertices,road_info.discretelanes[237].right_vertices,self_pos))
    #arr = np.vstack((np.array(road_info.discretelanes[237].left_vertices),np.array(road_info.discretelanes[237].right_vertices)))
    #print(arr)
    #print(str(len(road_info.discretelanes[237].left_vertices))+"***"+str(len(road_info.discretelanes[237].right_vertices))+"****"+str(len(arr)))
    '''
    rect = [0,3,5,-6]
    egoPos = [2,10,8,-9]
    pos = [3,10]
   
    '''
    

'''
    #_geometries 四组对象一个循环
    '<opendriveparser.elements.geometry.Spiral object at 0x7cd6a1ca85d0>, '
    '<opendriveparser.elements.geometry.Line object at 0x7cd6a1ca8690>, '
    '<opendriveparser.elements.geometry.Spiral object at 0x7cd6adcd0210>,'
    ' <opendriveparser.elements.geometry.Arc object at 0x7cd6a1ca8710>
    Spiral” 翻译成中文是 “螺旋” 或 “螺旋线
    arc 翻译成圆弧
    
    _precalculation
     num_steps = int(max(2, np.ceil(self.length / precision)))
        positions = np.linspace(0, self.length, num_steps)  # 对参考线进行线性插值
        self._precalculation = np.empty([num_steps, 4])  # 返回num_steps*4的浮点数组，4对应[pos, coord[0], coord[1], tang]
        for i, pos in enumerate(positions):
            coord, tang = self.calc_geometry(pos)  # 输出对应点的xy坐标及航向角Tuple[np.ndarray, float]
            self._precalculation[i] = (pos, coord[0], coord[1], tang)

    ****road_info.discretelanes[0]._parametric_lane_group.
          parametric_lanes[0].type_ 这是表示可以行使   driving

    **** print(road_info.discretelanes[1]._parametric_lane_group.
          inner_neighbour_same_direction)   True
    <road name = "Road 383" length="8.3992295060587622e*+01" id="383" junction="276" rule="RHT"
    

    print(road_info.discretelanes[10]._successor) ==> ['627.0.-3.-1'] 表示后一段路段编号为627,对应的627的车道号为-3
    print((road_info.discretelanes[10]._successor[0].split('.'))[0]) ==> 627
    print(road_info.discretelanes[10]._predecessor) ==> ['623.0.-1.-1']表示前一段路段编号为623,对应的623的车道号为-1
    print(road_info.discretelanes[10]._lane_id) ==> 3.0.-3.-1 表示当前路段编号为3,对应的3的车道号为-3
    print((road_info.discretelanes[10]._lane_id[0].split('.'))[0]) ==> 3

     print(road_info.discretelanes[11]._parametric_lane_group.id_) == > 3.0.-4.-1 和
     print(road_info.discretelanes[11]._lane_id) 
     print(road_info.discretelanes[11]._parametric_lane_group.parametric_lanes[0].id_  )
     三者输出是一样的

     print(road_info.discretelanes[11]._parametric_lane_group.inner_neighbour ) ==> 3.0.-3.-1 这个是输出相邻的车道

     print(road_info.discretelanes[11]._parametric_lane_group.outer_neighbour ) ==> 3.0.-5.-1 这个是输出相邻的车道
     
     print(road_info.discretelanes[11]._parametric_lane_group.parametric_lanes[0].type_ ) ==> driving
    
     
     roadmark ==>"broken"表示为虚线， "none" 表示为实线
      
     
     <width sOffset="0.0" a="3.5" b="0.0" c="0.0" d="0.0"/>
    <width sOffset="20.0" a="4.0" b="0.0" c="0.0" d="0.0"/>

    第一行表示从道路参考线的起点（s=0）开始，车道宽度为 3.5 米。

    第二行表示从 s=20.0 米处开始，车道宽度变为 4.0 米。

     # 检查是否已经驶出地图范围
        if not is_point_inside_rect(
            [[self.control_info.test_setting['map_range']['x'][0], self.control_info.test_setting['map_range']['y'][0]],
             [self.control_info.test_setting['map_range']['x'][1], self.control_info.test_setting['map_range']['y'][1]]],
            [observation.ego_info.x, observation.ego_info.y]
        ):
            status = 4
            logger.debug(f"(CODE-4): 测试车驶出地图边界")


'''
if __name__ == '__main__':
    main()