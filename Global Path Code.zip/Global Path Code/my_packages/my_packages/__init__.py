import sys
import os
import math
sys.path.append('/home/field/dev_ws/src/my_packages/my_mapping_package')
sys.path.append('/home/field/dev_ws/src/my_packages/my_planning_package')
import numpy as np
from scipy.spatial import KDTree

from map_parser.map_object import MapObject
from map_parser.map_parser import MapParser
from modules import lanes_module

from modules import lanecaculate_module

#from my_planning_package.lane_waypoint_planner import LaneWaypointPlanner



def main():
    #path_opendrive = r"H:\onsite结构化测试赛道\最新版本\onsite_structured_test\scenario\replay\intersection_12_61_0\intersection_12_61_0.xodr"
    print("ok")
    map_name = "hezimap"
    map_path = "/home/field/dev_ws/src/my_packages/my_mapping_package/maps/xodr/"

    map_object = MapObject(map_name, map_path)
    map_parser = MapParser(map_name, map_path)

    path_opendrive = '/home/field/hezimap.xodr'
    open_drive_info = lanecaculate_module.parse_opendrive(path_opendrive)
    #pos = [663.00,-120.26]
    #self_pos = [621.88,-149.43]
   
    #判断目标位置点书否可行
    #print(lanecaculate_module.operation(pos,self_pos,open_drive_info))
    #判断本车所在车道，用于激光雷达点云数据的按照车道过滤
    plane_count = len(open_drive_info.discretelanes)
    #arr = lanecaculate_module.operation_cloudpoint(self_pos,open_drive_info)
    start = [747.23,-381.97,0.0]
    stop = [254.06,-56.05,0.0]



    '''

    计算车道两侧的点迹位置函数在lanes_module里面 def calculate_lane(central_way):函数返回是lane类型的数据，lane在monitor_classes中
    map_object 的get_topology_waypoints函数

    '''
if __name__ == '__main__':
    main()